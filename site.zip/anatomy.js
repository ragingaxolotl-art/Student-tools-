import * as T from 'three';
import {OrbitControls} from './vendor/OrbitControls.js';
import {STLLoader} from './vendor/STLLoader.js';

const $=id=>document.getElementById(id);
const page=$('anatomyPage');
function reveal(){page.hidden=false;requestAnimationFrame(startModel)}
$('lockTab').addEventListener('click',()=>{window.resourceAccess.lock();page.hidden=true;window.resourceAccess.requestAccess(reveal)});
if(window.resourceAccess.isGranted())reveal();else window.resourceAccess.requestAccess(reveal);

let started=false;
async function startModel(){
  if(started)return;started=true;
  const canvas=$('anatomyCanvas'),stage=$('stage');
  try{
    const renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.setClearColor('#101722');renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;renderer.shadowMap.enabled=true;
    const scene=new T.Scene(),camera=new T.PerspectiveCamera(31,1,.1,100);camera.position.set(0,0,8.4);
    const controls=new OrbitControls(camera,canvas);controls.target.set(0,0,0);controls.enablePan=false;controls.minDistance=3.3;controls.maxDistance=14;controls.enableDamping=true;controls.dampingFactor=.075;
    scene.add(new T.HemisphereLight('#f8fbff','#29191e',1.65));
    const key=new T.DirectionalLight('#ffe7d4',4.8);key.position.set(-4,5,5);key.castShadow=true;scene.add(key);
    const fill=new T.DirectionalLight('#bad6ff',2.2);fill.position.set(4,1,3);scene.add(fill);
    const rim=new T.DirectionalLight('#ffad9c',1.45);rim.position.set(0,2,-5);scene.add(rim);

    const faceRoot=new T.Group();faceRoot.rotation.x=-Math.PI/2;faceRoot.scale.setScalar(.024);faceRoot.position.y=.1;scene.add(faceRoot);
    const root=new T.Group();root.rotation.x=-Math.PI/2;root.scale.setScalar(15);root.position.set(0,-.82,.44);scene.add(root);
    const upper=new T.Group(),lower=new T.Group();root.add(upper,lower);
    const faceMaterial=new T.MeshPhysicalMaterial({color:'#a96f5d',roughness:.84,sheen:.18,sheenColor:'#ffd3c7',clearcoat:.015,side:T.DoubleSide});
    const tissueMaterial=new T.MeshPhysicalMaterial({color:'#a94955',roughness:.58,sheen:.5,sheenColor:'#ffc8c8',clearcoat:.04,side:T.DoubleSide});
    const toothMaterial=new T.MeshPhysicalMaterial({color:'#efe8d9',roughness:.3,clearcoat:.18,clearcoatRoughness:.28,side:T.DoubleSide});
    const upperGumMaterial=new T.MeshPhysicalMaterial({color:'#b96b75',roughness:.56,sheen:.3,side:T.DoubleSide});
    const lowerGumMaterial=upperGumMaterial.clone();lowerGumMaterial.color.set('#ac5e6c');
    const loader=new STLLoader();
    async function part(path,material,parent,name){const geometry=await loader.loadAsync(path);geometry.computeVertexNormals();const mesh=new T.Mesh(geometry,material);mesh.name=name;mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh}
    const [face,tissue,upperTeeth,lowerTeeth,upperGums,lowerGums]=await Promise.all([
      part('./anatomy-assets/face-scan.stl',faceMaterial,faceRoot,'Photogrammetry face scan'),
      part('./anatomy-assets/face-and-mouth.stl',tissueMaterial,upper,'Lips, tongue and mouth tissue'),
      part('./anatomy-assets/upper-teeth.stl',toothMaterial,upper,'Upper teeth'),
      part('./anatomy-assets/lower-teeth.stl',toothMaterial,lower,'Lower teeth'),
      part('./anatomy-assets/upper-gums.stl',upperGumMaterial,upper,'Upper gums'),
      part('./anatomy-assets/lower-gums.stl',lowerGumMaterial,lower,'Lower gums')
    ]);
    face.geometry.center();$('loading').hidden=true;
    const original=tissue.geometry.attributes.position.array.slice(),positions=tissue.geometry.attributes.position.array;
    const state={jaw:0,tongueForward:0,tongueLift:0,pucker:0,width:0,opacity:1};
    const smooth=(edge0,edge1,x)=>{const t=Math.max(0,Math.min(1,(x-edge0)/(edge1-edge0)));return t*t*(3-2*t)};
    function deformTissue(){
      for(let i=0;i<positions.length;i+=3){const x=original[i],y=original[i+1],z=original[i+2];let nx=x,ny=y,nz=z;
        const lipBand=1-smooth(.010,.032,Math.abs(z)),front=smooth(-.005,-.045,-y),lipWeight=lipBand*front;
        nx*=1+state.width*.18*lipWeight;ny-=state.pucker*.014*lipWeight*(1-smooth(.02,.05,Math.abs(x)));
        const center=1-smooth(.018,.047,Math.abs(x)),inside=smooth(-.014,.035,y),lowerBand=smooth(.008,-.045,z),tongueWeight=center*inside*lowerBand;
        ny-=state.tongueForward*.020*tongueWeight;nz+=state.tongueLift*.018*tongueWeight;
        positions[i]=nx;positions[i+1]=ny;positions[i+2]=nz;
      }
      tissue.geometry.attributes.position.needsUpdate=true;tissue.geometry.computeVertexNormals();tissue.geometry.computeBoundingSphere();
    }
    function render(){renderer.render(scene,camera)}
    function update(){lower.rotation.x=-state.jaw*.32;lower.position.y=-state.jaw*.008;lower.position.z=-state.jaw*.006;tissueMaterial.transparent=state.opacity<.995;tissueMaterial.opacity=state.opacity;tissueMaterial.depthWrite=state.opacity>.45;tissueMaterial.needsUpdate=true;deformTissue();render()}
    const modes={complete:'Photogrammetry face scan',soft:'Sculpted lips, tongue & mouth tissue',teeth:'Individual teeth & gums',xray:'Face scan with internal mouth'};
    function setMode(mode){faceRoot.visible=mode==='complete'||mode==='xray';root.visible=mode!=='complete';tissue.visible=mode!=='teeth';upperTeeth.visible=lowerTeeth.visible=upperGums.visible=lowerGums.visible=mode!=='soft';state.opacity=mode==='xray'?.34:1;faceMaterial.transparent=mode==='xray';faceMaterial.opacity=mode==='xray'?.16:1;faceMaterial.depthWrite=mode!=='xray';faceMaterial.needsUpdate=true;document.querySelectorAll('[data-layer]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.layer===mode)));$('viewName').textContent=modes[mode];syncSliders();update()}
    document.querySelectorAll('[data-layer]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.layer)));
    const cameraViews={front:[0,0,8.4],three:[4.8,1.8,7.2],side:[8.4,0,.05]};
    function setCamera(view){camera.position.set(...cameraViews[view]);controls.target.set(0,0,0);controls.update();render()}
    document.querySelectorAll('[data-camera]').forEach(b=>b.addEventListener('click',()=>setCamera(b.dataset.camera)));$('resetView').onclick=()=>setCamera('front');
    const sliderMap=new Map();
    const defs=[['opacity','Tissue opacity',0,1,.01,'tissueSliders'],['width','Mouth width',-.8,.8,.01,'tissueSliders'],['pucker','Lip pucker',0,1,.01,'tissueSliders'],['jaw','Jaw opening',0,1,.01,'movementSliders'],['tongueLift','Tongue lift',-.5,1,.01,'movementSliders'],['tongueForward','Tongue forward',-.5,1,.01,'movementSliders']];
    for(const [key,label,min,max,step,target] of defs){const row=document.createElement('div');row.className='slider-row';const lab=document.createElement('label');lab.textContent=label;lab.htmlFor='real-'+key;const input=document.createElement('input');input.id=lab.htmlFor;input.type='range';input.min=min;input.max=max;input.step=step;input.value=state[key];const output=document.createElement('output');output.htmlFor=input.id;row.append(lab,input,output);$(target).append(row);sliderMap.set(key,{input,output});input.addEventListener('input',()=>{state[key]=Number(input.value);if(!root.visible)setMode('xray');if(key==='opacity'){$('viewName').textContent='Custom internal-tissue transparency'}update();syncSliders()})}
    function syncSliders(){for(const [key,{input,output}] of sliderMap){input.value=state[key];output.value=key==='opacity'?Math.round(state[key]*100)+'%':Math.round(state[key]*100)}}
    $('resetPose').onclick=()=>{Object.assign(state,{jaw:0,tongueForward:0,tongueLift:0,pucker:0,width:0,opacity:1});setMode('complete')};
    function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();render()}new ResizeObserver(resize).observe(stage);
    function loop(){controls.update();render();requestAnimationFrame(loop)}
    setMode('complete');syncSliders();resize();loop();
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();$('error').hidden=false;$('error').textContent='The 3D model paused because the graphics system was interrupted. Reload this tab to restart it.'});
  }catch(error){$('loading').hidden=true;$('error').hidden=false;$('error').textContent='The detailed mesh could not start. Try reloading in a browser with WebGL enabled. '+error.message}
}
