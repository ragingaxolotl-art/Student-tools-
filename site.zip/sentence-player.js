import { analyzeSentence,frameAt,guideText } from './sentence.js';
import { POSES } from './poses.js';
export function setupSentencePlayer({showPose,onStart,onFinish,exportVisualGuide}){
 const $=id=>document.getElementById(id);let dictionary=null,loading=null,plan=null,raf=0,playing=false,generation=0,offset=0,lastFrame=null,started=0,boundary=-1;
 async function prepare(){
  $('sentenceStatus').textContent='Preparing mouth shapes…';
  if(!dictionary){loading??=import('./vendor/cmudict.js');dictionary=(await loading).dictionary}
  plan=analyzeSentence($('sentenceText').value,dictionary,Number($('sentenceRate').value));
  $('sentenceWords').replaceChildren();for(const w of plan.words){const span=document.createElement('span');span.textContent=w.word;span.dataset.word=w.index;if(!w.pronunciation)span.classList.add('unknown-word');$('sentenceWords').append(span)}
  $('sentenceStatus').textContent=plan.unknown.length?`No pronunciation found: ${plan.unknown.join(', ')}. Those words will stay neutral. Spell numbers out.`:'Ready. Mouth shapes use dictionary pronunciations; speech alignment is approximate.';
  return plan;
 }
 function stop(restore=true){generation++;playing=false;cancelAnimationFrame(raf);if('speechSynthesis' in window)window.speechSynthesis.cancel();$('sentencePlay').disabled=false;$('sentenceStop').disabled=true;document.querySelectorAll('[data-word]').forEach(x=>x.classList.remove('speaking-word'));if(restore)onFinish()}
 function tick(now){if(!playing)return;const elapsed=(now-started)/1000+offset;const frame=frameAt(plan,elapsed);
  if(frame!==lastFrame){lastFrame=frame;showPose(frame?.shape||'rest');for(const el of $('sentenceWords').children)el.classList.toggle('speaking-word',Number(el.dataset.word)===frame?.wordIndex);$('sentenceShape').textContent=frame?`${plan.words[frame.wordIndex].word} · ${frame.phone} → ${POSES[frame.shape].name}`:'Between sounds';}
  if(!$('speakSentence').checked&&elapsed>plan.duration){stop();$('sentenceStatus').textContent='Finished.';return}raf=requestAnimationFrame(tick);
 }
 async function play(){stop();const token=++generation;playing=true;$('sentencePlay').disabled=true;$('sentenceStop').disabled=false;
  try{await prepare();if(token!==generation)return;onStart();lastFrame=null;offset=0;boundary=-1;playing=true;$('sentenceStop').disabled=false;
   const begin=()=>{if(token!==generation)return;started=performance.now();raf=requestAnimationFrame(tick)};
   if($('speakSentence').checked){
    if(!('speechSynthesis' in window))throw Error('Speech is unavailable. Uncheck Speak sentence to animate silently.');
    const u=new SpeechSynthesisUtterance(plan.text);u.lang='en-US';u.rate=plan.rate;u.onstart=begin;
    u.onboundary=e=>{if(token!==generation||e.name==='sentence')return;const word=plan.words.find(w=>e.charIndex>=w.charIndex&&e.charIndex<w.endChar);if(word&&word.index>boundary){boundary=word.index;offset=word.start;started=performance.now()}};
    u.onend=()=>{if(token!==generation)return;stop();$('sentenceStatus').textContent=plan.unknown.length?'Finished. Some words need pronunciation review.':'Finished.'};
    u.onerror=()=>{if(token!==generation)return;stop();$('sentenceStatus').textContent='Speech could not play. Uncheck Speak sentence to animate silently.'};
    window.speechSynthesis.speak(u);
   }else begin();
  }catch(error){if(token!==generation)return;stop();$('sentenceStatus').textContent=error.message}
 }
 $('sentencePlay').onclick=play;$('sentenceStop').onclick=()=>{stop();$('sentenceStatus').textContent='Stopped.'};
 $('sentenceText').addEventListener('input',()=>{if(playing)stop();plan=null;$('sentenceWords').replaceChildren();$('sentenceShape').textContent='';$('sentenceStatus').textContent='Text changed. Press Play or Download TXT to prepare the new sentence.'});
 $('sentenceRate').onchange=()=>{if(playing)stop()};$('speakSentence').onchange=()=>{if(playing)stop()};
 $('downloadGuide').onclick=async()=>{try{if(playing)stop();const p=await prepare();const blob=new Blob([guideText(p)],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='mouth-shapes.txt';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);$('sentenceStatus').textContent='Mouth-shape TXT downloaded.'}catch(e){$('sentenceStatus').textContent=e.message}};
 for(const [id,format] of [['downloadPng','png'],['downloadPdf','pdf']])$(id).onclick=async()=>{try{if(playing)stop();$(id).disabled=true;const p=await prepare();$('sentenceStatus').textContent=`Creating picture ${format.toUpperCase()}…`;await exportVisualGuide(p,format);$('sentenceStatus').textContent=`Viseme picture ${format.toUpperCase()} downloaded.`}catch(e){$('sentenceStatus').textContent=e.message}finally{$(id).disabled=false}};
 if(!('speechSynthesis' in window)){$('speakSentence').checked=false;$('speakSentence').disabled=true}
 window.addEventListener('pagehide',()=>stop(false));return{stop,isPlaying:()=>playing};
}
