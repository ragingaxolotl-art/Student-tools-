import * as T from 'three';
import { BASE, constrain } from './poses.js';
const V=(x,y,z)=>new T.Vector3(x,y,z);
const mix=T.MathUtils.lerp;
const smooth=(a,b,x)=>T.MathUtils.smoothstep(x,a,b);
export function jawPoint(p,s) {
  const a=s.jaw*.48, y=p.y-.36,z=p.z+.34;
  return V(p.x, .36+y*Math.cos(a)-z*Math.sin(a), -.34+y*Math.sin(a)+z*Math.cos(a)+s.forward*.16+s.jaw*.08);
}
export function lipPoint(a,s) {
  const sn=Math.sin(a),co=Math.cos(a),seam=.025;
  let top=mix(.08+s.upper*.20,seam,s.seal);
  let bottom=mix(jawPoint(V(0,-.14,1.04),s).y+s.lower*.37,seam,s.seal);
  bottom=Math.min(top,bottom);
  const center=(top+bottom)/2;
  const y=center+(sn>=0?(top-center):(center-bottom))*sn;
  // Lip closure controls the vertical seam only. Keeping each lip's depth
  // independent lets the lower lip roll behind the upper lip or incisors even
  // while the mouth is closed.
  const depth=(sn>=0?s.upperLipDepth:s.lowerLipDepth)*Math.abs(sn);
  return V(s.width*(1-.32*s.pucker)*co,y,1.28+.20*s.pucker+.16*s.lipDepth+.34*depth-.12*Math.pow(Math.abs(co),1.6));
}
export function lipSurface(a,v,s,part) {
  const p=lipPoint(a,s),normal=V(Math.cos(a),Math.sin(a),0);
  // The inner edge is the actual mouth opening. Both inner edges coincide when sealed.
  const scale=part==='upper'?s.upperLipThickness:part==='lower'?s.lowerLipThickness:Math.sin(a)>=0?s.upperLipThickness:s.lowerLipThickness;
  const thickness=(.105+.02*s.pucker)*scale;
  p.addScaledVector(normal,thickness*(1+Math.cos(v))/2);
  p.z+=.085*scale*Math.sin(v);
  // Moving the lower lip inward rolls its inner surface up and back over the
  // lower incisors rather than translating it as a flat strip.
  const lowerWeight=Math.max(0,-Math.sin(a)),tuck=Math.max(0,-s.lowerLipDepth)*lowerWeight,inner=(1-Math.cos(v))/2;
  p.z-=.11*tuck*inner;p.y+=.075*tuck*inner;
  return p;
}
export function tonguePoint(u,v,s) {
  const tipZ=Math.min(.78+s.tongueForward*.57, s.seal>.95?lipPoint(Math.PI/2,s).z-.18:2);
  const radius=Math.pow(Math.sin(Math.PI*u),.40);
  const middle=Math.exp(-Math.pow((u-.60)/.22,2));
  const underside=Math.max(0,-Math.sin(v))*radius*s.tongueUnderCurl;
  const z=mix(-.24,tipZ,u)-s.tongueCurl*.1*Math.pow(u,4)-underside*.16*(.35+.65*u);
  const y=-.29+s.tongueUp*.33+s.tongueMiddle*.28*middle+s.tongueBack*.32*Math.exp(-Math.pow((u-.30)/.25,2))+s.tongueCurl*.30*Math.pow(u,4)+underside*.05;
  // Deliberately use the authored tongue surface directly. This keeps dragging
  // smooth and predictable near the teeth; intersections are allowed.
  return jawPoint(V(s.tongueSide*.28*u*u+Math.cos(v)*.38*radius,y+Math.sin(v)*.095*radius,z),s);
}
function grid(n,m,fn,wrap=false) {
  const rows=wrap?n:n+1,geom=new T.BufferGeometry(),p=new Float32Array(rows*(m+1)*3),ix=[];
  for(let i=0;i<n;i++)for(let j=0;j<m;j++){let a=i*(m+1)+j,b=((i+1)%rows)*(m+1)+j;ix.push(a,b,a+1,b,b+1,a+1)}
  geom.setAttribute('position',new T.BufferAttribute(p,3));geom.setIndex(ix);
  geom.userData.update=(...args)=>{for(let i=0;i<rows;i++)for(let j=0;j<=m;j++){const v=fn(i/n,j/m,...args);const k=(i*(m+1)+j)*3;p[k]=v.x;p[k+1]=v.y;p[k+2]=v.z}geom.attributes.position.needsUpdate=true;geom.computeVertexNormals();geom.computeBoundingSphere()};
  return geom;
}
function tubeGeometry(fn,n=64,r=.06) {
  return grid(n,10,(u,v,s)=>{const a=fn(u,s),next=fn(Math.min(1,u+.002),s),prev=fn(Math.max(0,u-.002),s),t=next.sub(prev).normalize(),normal=V(-t.y,t.x,0).normalize(),binormal=t.clone().cross(normal).normalize();return a.addScaledVector(normal,r*Math.cos(v*Math.PI*2)).addScaledVector(binormal,r*Math.sin(v*Math.PI*2))});
}
export function createRig() {
  const root=new T.Group(), skull=new T.Group(), jaw=new T.Group(), skin=new T.Group(), soft=new T.Group();
  root.add(skull,jaw,skin,soft);skull.name='Fixed cranium and maxilla';jaw.name='Mandible';
  const materials=[];
  const mat=(color,extra={})=>{const m=new T.MeshPhysicalMaterial({color,roughness:.62,side:T.DoubleSide,...extra});materials.push(m);return m};
  const bone=mat('#eadfc4',{roughness:.76}),enamel=mat('#fffbed',{roughness:.22,clearcoat:.15}),skinMat=mat('#d2a38f',{roughness:.72,sheen:.08,sheenColor:new T.Color('#efc4b1')}),lipMat=mat('#a7505e',{roughness:.36,clearcoat:.12}),tongueMat=mat('#d8617a',{roughness:.42,clearcoat:.08}),cavityMat=mat('#4d2934',{roughness:.9}),cartoonCavityMat=mat('#050506',{roughness:1}),socketMat=mat('#4d4948',{roughness:.9}),irisMat=mat('#656f79',{roughness:.3,clearcoat:.2});
  const deform=[];
  const mesh=(geo,material,parent,name)=>{const m=new T.Mesh(geo,material);m.name=name||'';parent.add(m);return m};
  const ell=(parent,material,pos,scale,name)=>{const m=mesh(new T.SphereGeometry(1,36,24),material,parent,name);m.position.set(...pos);m.scale.set(...scale);return m};
  const tube=(points,r,parent,material,name)=>mesh(new T.TubeGeometry(new T.CatmullRomCurve3(points.map(p=>V(...p))),48,r,10,false),material,parent,name);
  // A simplified bony base: cranial vault, orbital rims, nasal opening and maxilla.
  const vault=ell(skull,bone,[0,1.32,-.25],[.91,1.0,.86],'Cranial vault');
  const plate=new T.Shape();plate.moveTo(-.86,.38);plate.bezierCurveTo(-1.04,1.0,-.91,1.91,0,1.98);plate.bezierCurveTo(.91,1.91,1.04,1,.86,.38);plate.lineTo(.53,.16);plate.lineTo(-.53,.16);plate.closePath();
  for(const sign of [-1,1]){const h=new T.Path();h.absellipse(sign*.43,1.09,.30,.275,0,Math.PI*2,true);plate.holes.push(h)}
  const noseHole=new T.Path();noseHole.moveTo(0,.95);noseHole.lineTo(.18,.48);noseHole.quadraticCurveTo(0,.37,-.18,.48);noseHole.closePath();plate.holes.push(noseHole);
  const faceBone=mesh(new T.ExtrudeGeometry(plate,{depth:.18,bevelEnabled:true,bevelThickness:.055,bevelSize:.035,bevelSegments:3,steps:1}),bone,skull,'Facial bones and eye sockets');faceBone.position.z=.34;faceBone.scale.x=.89;
  for(const sign of [-1,1]){ell(skull,socketMat,[sign*.43,1.09,.515],[.29,.27,.11],'Orbital cavity');tube([[sign*.66,.68,.57],[sign*.94,.56,.22],[sign*.87,.50,-.29]],.09,skull,bone,'Zygomatic arch');ell(skull,bone,[sign*.83,.36,-.34],[.135,.11,.14],'Jaw joint')}
  ell(skull,bone,[0,.27,.61],[.49,.22,.24],'Maxilla');
  // Teeth are attached to their corresponding bony arch, never to the skin.
  function teeth(parent,lower=false){for(let i=0;i<14;i++){const a=-1.45+i*2.90/13;const x=.54*Math.sin(a),z=.27+.62*Math.cos(a);const tooth=mesh(new T.BoxGeometry(.122,.18,.145,1,1,1),enamel,parent,lower?'Lower tooth':'Upper tooth');tooth.position.set(x,lower?-.135:.045,z);tooth.rotation.y=a}}
  teeth(skull);teeth(jaw,true);
  tube([[-.82,.36,-.34],[-.85,-.12,-.29],[-.73,-.53,.05],[-.43,-.58,.48],[0,-.62,.63],[.43,-.58,.48],[.73,-.53,.05],[.85,-.12,-.29],[.82,.36,-.34]],.10,jaw,bone,'Mandibular body and rami');
  tube([[-.55,-.27,.33],[-.38,-.28,.67],[0,-.28,.83],[.38,-.28,.67],[.55,-.27,.33]],.10,jaw,bone,'Lower tooth-bearing arch');
  const floor=ell(jaw,cavityMat,[0,-.34,.34],[.52,.10,.56],'Floor of mouth');
  const palate=ell(skull,bone,[0,.21,.44],[.55,.055,.58],'Hard palate');
  // One wrapped surface runs from the mouth to the back pole. Sharing the side
  // vertices removes both the old halfway join and the vertical lighting seam.
  const faceGeo=grid(112,70,(u,v,s)=>{
    const a=u*Math.PI*2,co=Math.cos(a),sn=Math.sin(a),p=lipPoint(a,s);
    const upperWeight=smooth(-.12,.12,sn),lipScale=mix(s.lowerLipThickness,s.upperLipThickness,upperWeight);
    const upperBand=smooth(.08,.92,sn),lowerBand=smooth(.08,.92,-sn),lowerTuck=Math.max(0,-s.lowerLipDepth);
    const normal=V(co,sn,0);p.addScaledVector(normal,(.105+.02*s.pucker)*lipScale);
    // The labiomental skin follows a tucked or hidden lower lip, then stretches
    // back over the jaw. Its separate depth control adjusts this fold without
    // moving the lip itself.
    const upperSkinGuard=upperBand*Math.max(0,-s.upperLipDepth)*(1-s.upperLipThickness)*.15;
    const hiddenTuckGuard=lowerBand*lowerTuck*(1-lipScale)*.075;
    p.z+=upperSkinGuard+hiddenTuckGuard+lowerBand*(.12*s.lowerSkinDepth-.04*lowerTuck);p.y+=lowerBand*.045*lowerTuck;p.z-=.035;
    const outer=V(1.18*co*(1+.035*sn),.55+2.02*sn,.03-.06*sn);
    const jw=1-smooth(-.34,.38,outer.y);outer.lerp(jawPoint(outer,s),jw);
    if(v<=.5){
      const k=smooth(0,1,v*2),point=p.clone().lerp(outer,k);
      const envelope=.96*Math.sqrt(Math.max(0,1-(point.x/1.19)**2-((point.y-.55)/2.03)**2));
      // Thin lips and a tucked lower fold need a shorter transition so the
      // surrounding skin clears the skull instead of cutting through it.
      const stretch=Math.max(1-lipScale,lowerBand*lowerTuck),guardEnd=mix(.15,.065,stretch);
      point.z=Math.max(point.z,envelope*smooth(0,guardEnd,v));return point;
    }
    const k=(v-.5)*Math.PI,ck=Math.cos(k),sk=Math.sin(k);
    const back=V(1.18*co*(1+.035*sn)*ck,.55+2.02*sn*ck,(.03-.06*sn)*ck-1.40*sk);
    return back.lerp(jawPoint(back,s),1-smooth(-.34,.38,back.y));
  },true);
  const faceSkin=mesh(faceGeo,skinMat,skin,'Deformable facial skin');deform.push(faceGeo);
  const nose=ell(skin,skinMat,[0,.64,1.17],[.13,.36,.20],'Nose');ell(skin,skinMat,[0,.43,1.32],[.17,.14,.18],'Nose tip');
  for(const sign of [-1,1]){ell(skin,skinMat,[sign*1.065,.67,-.10],[.12,.29,.18],'Ear');ell(skin,enamel,[sign*.44,1.13,.935],[.20,.12,.085],'Eye');ell(skin,irisMat,[sign*.44,1.13,1.012],[.068,.075,.02],'Iris')}
  const upperLipGeo=grid(64,20,(u,v,s)=>lipSurface(u*Math.PI,v*Math.PI*2,s,'upper'));
  const lowerLipGeo=grid(64,20,(u,v,s)=>lipSurface(Math.PI+u*Math.PI,v*Math.PI*2,s,'lower'));
  const upperLip=mesh(upperLipGeo,lipMat,soft,'Upper lip');upperLip.userData.part='upper';
  const lowerLip=mesh(lowerLipGeo,lipMat,soft,'Lower lip');lowerLip.userData.part='lower';deform.push(upperLipGeo,lowerLipGeo);
  const mouthBackdrop=ell(soft,cartoonCavityMat,[0,-.06,.08],[.62,.62,.04],'Black oral cavity');mouthBackdrop.visible=false;
  const tongueGeo=grid(48,24,(u,v,s)=>tonguePoint(u,v*Math.PI*2,s));const tongue=mesh(tongueGeo,tongueMat,soft,'Tongue');tongue.userData.part='tongueTip';deform.push(tongueGeo);
  // Small control markers are actual raycast targets in 3D space.
  const handles=new T.Group();root.add(handles);const handleMap={};
  const colors={upper:'#f5a3b0',lower:'#f5a3b0',left:'#f5a3b0',right:'#f5a3b0',tongueTip:'#4be0c2',tongueBack:'#4be0c2',chin:'#79aaff'};
  for(const [key,color] of Object.entries(colors)){const m=mesh(new T.SphereGeometry(key==='chin'?.085:.063,20,14),new T.MeshBasicMaterial({color,depthTest:false,transparent:true,opacity:1}),handles,key);m.renderOrder=10;m.userData.part=key;handleMap[key]=m;}
  let current={...BASE},mode='skin';
  function update(s) {
    current=constrain({...s});const a=current.jaw*.48;
    jaw.rotation.x=a;
    jaw.position.set(0,.36-.36*Math.cos(a)-.34*Math.sin(a),-.34-.36*Math.sin(a)+.34*Math.cos(a)+current.forward*.16+current.jaw*.08);
    for(const geo of deform)geo.userData.update(current);
    upperLip.visible=current.upperLipThickness>.001;
    lowerLip.visible=current.lowerLipThickness>.001;
    handleMap.upper.position.copy(lipPoint(Math.PI/2,current)).z+=.072;
    handleMap.lower.position.copy(lipPoint(3*Math.PI/2,current)).z+=.072;
    handleMap.upper.position.y+=.065;
    handleMap.lower.position.y-=.065;
    handleMap.right.position.copy(lipPoint(0,current)).z+=.06;
    handleMap.left.position.copy(lipPoint(Math.PI,current)).z+=.06;
    handleMap.tongueTip.position.copy(tonguePoint(.94,Math.PI/2,current));
    handleMap.tongueBack.position.copy(tonguePoint(.40,Math.PI/2,current));
    handleMap.chin.position.copy(jawPoint(V(0,-1.10,.70),current));
    root.updateMatrixWorld(true);
  }
  const clip=new T.Plane(V(-1,0,0),0);
  function setMode(next) {
    mode=next;skin.visible=next!=='skull'&&next!=='cutaway';
    if(next==='mouth')skin.visible=false;
    // The dark oral cavity belongs behind the visible teeth and tongue in the
    // normal reference view as well as the isolated mouth view. Depth testing
    // lets the lips and facial skin naturally mask it when the mouth closes.
    mouthBackdrop.visible=next==='skin'||next==='mouth';
    skull.children.forEach(m=>m.visible=next!=='mouth'||m.name==='Upper tooth');
    jaw.children.forEach(m=>m.visible=next!=='mouth'||m.name==='Lower tooth');
    skinMat.transparent=next==='xray';skinMat.opacity=next==='xray'?.16:1;skinMat.depthWrite=next!=='xray';skinMat.needsUpdate=true;
    // Eye materials are shared with teeth, so hide individual eye meshes rather than alter the material.
    skin.children.forEach(m=>{if(['Eye','Iris'].includes(m.name))m.visible=next==='skin'});
    for(const m of materials){m.clippingPlanes=next==='cutaway'?[clip]:[];m.needsUpdate=true}
    handleMap.left.visible=true;handleMap.right.visible=next!=='cutaway';
    handleMap.tongueTip.visible=next!=='skin';handleMap.tongueBack.visible=next!=='skin';
  }
  update(current);setMode(mode);
  return {root,skull,jaw,skin,soft,handles,handleMap,upperLip,lowerLip,tongue,mouthBackdrop,materials,update,setMode,get state(){return {...current}},get mode(){return mode}};
}
