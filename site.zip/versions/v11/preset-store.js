import { POSES,constrain } from './poses.js';
function normalize(id,value){
  if(!Object.hasOwn(POSES,id)||!value||typeof value!=='object')return null;
  const next={...POSES[id].values};
  for(const key of Object.keys(next))if(Number.isFinite(value[key]))next[key]=value[key];
  try{return constrain(next)}catch{return null}
}
async function requestJson(fetchImpl,path,options={}){
  const response=await fetchImpl(path,{...options,headers:{'content-type':'application/json',...(options.headers||{})}});
  let body={};try{body=await response.json()}catch{}
  if(!response.ok){const error=new Error(body.error||'The shared viseme service is unavailable.');error.status=response.status;throw error}
  return body;
}
export async function createPresetStore(fetchImpl=globalThis.fetch){
  let custom={};
  let available=true;
  try{const loaded=await requestJson(fetchImpl,'/api/presets');for(const [id,value] of Object.entries(loaded.presets||{})){const valid=normalize(id,value);if(valid)custom[id]=valid}}catch{available=false}
  return{
    get(id){if(!Object.hasOwn(POSES,id))throw Error('Unknown viseme');return{...(custom[id]||POSES[id].values)}},
    has(id){return Object.hasOwn(custom,id)},
    async save(id,value,pin){const valid=normalize(id,value);if(!valid)throw Error('The adjusted viseme is invalid.');await requestJson(fetchImpl,`/api/presets/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({pin,values:valid})});custom[id]=valid;available=true;return{...valid}},
    async reset(id,pin){if(!Object.hasOwn(POSES,id))throw Error('Unknown viseme');await requestJson(fetchImpl,`/api/presets/${encodeURIComponent(id)}`,{method:'DELETE',body:JSON.stringify({pin})});delete custom[id];available=true;return this.get(id)},
    async resetAll(pin){await requestJson(fetchImpl,'/api/presets',{method:'DELETE',body:JSON.stringify({pin})});custom={};available=true},
    ids(){return Object.keys(custom)},
    get available(){return available}
  };
}
export async function verifyEditorPin(pin,fetchImpl=globalThis.fetch){
  try{await requestJson(fetchImpl,'/api/presets/unlock',{method:'POST',body:JSON.stringify({pin})});return true}catch(error){if(error.status===403)return false;throw error}
}
