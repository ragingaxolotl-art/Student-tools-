import { POSES } from './poses.js';
export function guideFrames(plan){return plan.frames.map((frame,index)=>({...frame,index,word:plan.words[frame.wordIndex]?.word||''}))}
function rounded(ctx,x,y,w,h,r=12){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();ctx.stroke()}
export function buildVisualGuide(plan,images){
  const cards=guideFrames(plan),columns=5,cardW=238,cardH=225,pad=28,header=150;
  const rows=Math.ceil(cards.length/columns),canvas=document.createElement('canvas');canvas.width=pad*2+columns*cardW;canvas.height=header+pad+rows*cardH;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#f4f7fb';ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle='#18243a';ctx.font='700 34px system-ui,sans-serif';ctx.fillText('Viseme Mouth Lab — Picture Guide',pad,48);
  ctx.font='20px system-ui,sans-serif';const sentence=plan.text.length>96?plan.text.slice(0,93)+'…':plan.text;ctx.fillText(sentence,pad,83);
  ctx.fillStyle='#506078';ctx.font='16px system-ui,sans-serif';ctx.fillText('Read left to right. Each picture uses the same 3D pose as Browse visual visemes.',pad,116);
  for(const card of cards){
    const col=card.index%columns,row=Math.floor(card.index/columns),x=pad+col*cardW,y=header+row*cardH;
    ctx.fillStyle='#fff';ctx.strokeStyle='#ccd5e2';ctx.lineWidth=2;rounded(ctx,x+6,y+4,cardW-12,cardH-12,12);
    const image=images.get(card.shape);if(image)ctx.drawImage(image,x+15,y+13,cardW-30,150);
    ctx.fillStyle='#18243a';ctx.font='700 17px system-ui,sans-serif';ctx.textAlign='center';ctx.fillText(POSES[card.shape].name,x+cardW/2,y+184,cardW-28);
    ctx.fillStyle='#5b687b';ctx.font='14px system-ui,sans-serif';ctx.fillText(`${card.phone} · ${card.word}`,x+cardW/2,y+207,cardW-28);ctx.textAlign='left';
  }
  return canvas;
}
function downloadBlob(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200)}
export async function downloadVisualGuide(canvas,format){
  if(format==='png'){
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('The PNG guide could not be created.');downloadBlob(blob,'viseme-picture-guide.png');return;
  }
  const JsPDF=globalThis.jspdf?.jsPDF;if(!JsPDF)throw Error('The PDF creator did not load. Reload the page and try again.');
  const pdf=new JsPDF({orientation:'portrait',unit:'pt',format:'letter'}),pageW=612,pageH=792,margin=24,drawW=pageW-margin*2,drawH=pageH-margin*2;
  const sourceH=Math.floor(canvas.width*drawH/drawW),pages=Math.ceil(canvas.height/sourceH);
  for(let page=0;page<pages;page++){
    if(page)pdf.addPage();const height=Math.min(sourceH,canvas.height-page*sourceH),slice=document.createElement('canvas');slice.width=canvas.width;slice.height=height;
    const ctx=slice.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,slice.width,slice.height);ctx.drawImage(canvas,0,page*sourceH,canvas.width,height,0,0,canvas.width,height);
    const renderedH=height*drawW/canvas.width;pdf.addImage(slice.toDataURL('image/jpeg',.9),'JPEG',margin,margin,drawW,renderedH,undefined,'FAST');
  }
  pdf.save('viseme-picture-guide.pdf');
}
