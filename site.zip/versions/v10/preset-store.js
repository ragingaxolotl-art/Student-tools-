import { POSES,constrain } from './poses.js';
const STORAGE_KEY='viseme-mouth-lab-custom-poses-v1';
const PIN_HASH='97f2f9fe286a15e921dcd596f1e5dbdbbaf83fb31e7e4d7708e114454153985e';
function normalize(id,value){
  if(!Object.hasOwn(POSES,id)||!value||typeof value!=='object')return null;
  const next={...POSES[id].values};
  for(const key of Object.keys(next))if(Number.isFinite(value[key]))next[key]=value[key];
  try{return constrain(next)}catch{return null}
}
export function createPresetStore(storage=globalThis.localStorage){
  let custom={};
  try{const parsed=JSON.parse(storage.getItem(STORAGE_KEY)||'{}');for(const [id,value] of Object.entries(parsed)){const valid=normalize(id,value);if(valid)custom[id]=valid}}catch{}
  const persist=()=>{try{storage.setItem(STORAGE_KEY,JSON.stringify(custom))}catch{throw Error('This browser could not save the viseme. Check its storage settings.')}};
  return{
    get(id){if(!Object.hasOwn(POSES,id))throw Error('Unknown viseme');return{...(custom[id]||POSES[id].values)}},
    has(id){return Object.hasOwn(custom,id)},
    save(id,value){const valid=normalize(id,value);if(!valid)throw Error('The adjusted viseme is invalid.');custom[id]=valid;persist();return{...valid}},
    reset(id){delete custom[id];persist();return this.get(id)},
    resetAll(){custom={};persist()},
    ids(){return Object.keys(custom)}
  };
}
export async function verifyEditorPin(pin){
  const bytes=await globalThis.crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(pin)));
  const hash=[...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('');
  return hash===PIN_HASH;
}
