export const LIMITS = {
  jaw:[0,1], forward:[0,1], width:[0.28,0.87], pucker:[0,1], lipDepth:[-1,1], upperLipDepth:[-1,1], lowerLipDepth:[-1,1], upperLipThickness:[0,1], lowerLipThickness:[0,1], lowerSkinDepth:[-0.5,1], seal:[0,1],
  upper:[-1.5,1], lower:[-0.5,2.2], tongueUp:[0,1], tongueMiddle:[0,1], tongueForward:[0,1], tongueCurl:[-0.5,1], tongueUnderCurl:[0,1], tongueSide:[-1,1], tongueBack:[0,1]
};
export const BASE = {jaw:.18,forward:0,width:.58,pucker:0,lipDepth:0,upperLipDepth:0,lowerLipDepth:0,upperLipThickness:1,lowerLipThickness:1,lowerSkinDepth:0,seal:0,upper:0,lower:0,tongueUp:.2,tongueMiddle:.15,tongueForward:.25,tongueCurl:0,tongueUnderCurl:.35,tongueSide:0,tongueBack:.15};
const pose=(name,ipa,word,note,p)=>({name,ipa,word,note,values:{...BASE,...p}});
export const POSES = {
  rest:pose('Neutral pose','—','','Returns the mouth to a relaxed starting position with the jaw slightly open.',{jaw:.08,pucker:1,lipDepth:-1,lowerLipDepth:-1,lowerSkinDepth:.46,seal:1}),
  m:pose('M · B · P','m b p','map','Both lips close. M holds the closure; B and P build pressure and release it.',{jaw:.03,seal:1,width:.55}),
  f:pose('F · V','f v','five','The jaw stays nearly closed while the inside of the lower lip rests just beneath the upper incisors.',{jaw:.10,lower:.43,upper:0,width:.60,lipDepth:-1,lowerLipDepth:.16,lowerLipThickness:0,lowerSkinDepth:1}),
  th:pose('TH','θ ð','think','The tongue tip sits lightly between the incisors or against the back of the upper incisors.',{jaw:.26,width:.62,tongueForward:.69,tongueUp:.36,tongueMiddle:0,tongueCurl:1,tongueUnderCurl:1,tongueBack:0}),
  t:pose('T · D · N','t d n','ten','The inverse of the S profile: the tongue tip rises behind the upper incisors while the middle stays lower.',{jaw:.07,width:.61,tongueUp:.50,tongueMiddle:.12,tongueCurl:1,tongueForward:.42,tongueUnderCurl:.75}),
  l:pose('L','l','lamp','The tongue tip rises behind the upper incisors while the middle and sides stay lower.',{jaw:.36076089177169396,width:.4536932398228656,lipDepth:-.13558789873728827,lowerLipDepth:-.039276007145410734,upper:-.06135958565699984,lower:-.1619809374678382,tongueUp:.62,tongueMiddle:0,tongueCurl:1,tongueForward:.39402408276860207,tongueUnderCurl:0,tongueSide:.04578643873556221,tongueBack:0}),
  k:pose('K · G · NG','k g ŋ','king','The back of the tongue rises toward the soft palate; the tongue tip stays low.',{jaw:.24,width:.60,tongueUp:0,tongueMiddle:0,tongueBack:0,tongueForward:.1}),
  s:pose('S · Z','s z','sun','The teeth nearly meet while the raised tongue middle forms a narrow air channel behind the alveolar ridge.',{jaw:0,width:.66,lipDepth:-1,upper:.4,lower:-.3,tongueUp:.3220723336585704,tongueMiddle:0,tongueForward:0,tongueCurl:-.5,tongueUnderCurl:1,tongueSide:-.1649502657648976,tongueBack:0}),
  ch:pose('SH · CH · J','ʃ ʒ tʃ dʒ','shoe','The tongue blade and middle rise behind the alveolar ridge; the lips usually round for SH and CH.',{jaw:0,forward:.07918621268055981,width:.40,pucker:.48,tongueUp:0,tongueMiddle:0,tongueForward:0,tongueUnderCurl:1,tongueSide:1,tongueBack:0}),
  r:pose('R','ɹ','red','A simplified retroflex American R: the middle rises and the tongue tip curls up without touching the palate. A bunched R is also common.',{jaw:.19,width:.43,pucker:.35,tongueUp:.36,tongueMiddle:.72,tongueCurl:.9,tongueForward:.08,tongueUnderCurl:.8}),
  w:pose('W','w','we','The lips form a narrow rounded opening while the back of the tongue rises toward the soft palate.',{jaw:.09,width:.30,pucker:.9,tongueMiddle:0,tongueBack:0,tongueForward:.1}),
  ee:pose('EE · IH','i ɪ','see','The lips spread and the front and middle of the tongue rise. IH is usually lower and more relaxed than EE.',{jaw:.08,width:.82,upper:.2,tongueUp:0,tongueMiddle:0,tongueForward:.06578200130572318,tongueSide:-1,tongueBack:0}),
  eh:pose('EH · AE','ɛ æ','cat','The lips are unrounded and the tongue stays forward; AE opens the jaw more than EH.',{jaw:.5026717248265785,width:.76,tongueUp:.006791401012517073,tongueForward:.059702544850472106,tongueSide:-.061507299003814096}),
  ah:pose('AH · UH','ɑ ʌ','hot','The jaw opens and the tongue stays low and relatively central.',{jaw:.8,width:.6,tongueUp:.1,tongueForward:.3}),
  oh:pose('OH','oʊ ɔ','go','The lips round and the tongue shifts toward the back. Spoken OH often moves toward an OO shape.',{jaw:.46,width:.38,pucker:.65,tongueBack:.5,tongueForward:.2}),
  oo:pose('OO','u ʊ','blue','The lips make a small rounded opening and the back of the tongue rises. UH in “book” is more relaxed.',{jaw:.25,width:.29,pucker:1,tongueUp:0,tongueMiddle:0,tongueForward:0,tongueSide:.15938411837088978,tongueBack:0})
};
export function constrain(state) {
  for(const [key,[min,max]] of Object.entries(LIMITS)) {
    if(!Number.isFinite(state[key])) throw new Error(`Invalid ${key}`);
    state[key]=Math.max(min,Math.min(max,state[key]));
  }
  return state;
}
