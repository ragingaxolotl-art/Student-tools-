export const LIMITS = {
  jaw:[0,1], forward:[0,1], width:[0.28,0.87], pucker:[0,1], seal:[0,1],
  upper:[-0.5,1], lower:[-0.5,1], tongueUp:[0,1], tongueForward:[0,1], tongueCurl:[-0.5,1], tongueSide:[-1,1], tongueBack:[0,1]
};
export const BASE = {jaw:.18,forward:0,width:.58,pucker:0,seal:0,upper:0,lower:0,tongueUp:.2,tongueForward:.25,tongueCurl:0,tongueSide:0,tongueBack:.15};
const pose=(name,ipa,word,note,p)=>({name,ipa,word,note,values:{...BASE,...p}});
export const POSES = {
  rest:pose('Rest','—','','Start with a sound, then drag the colored grab points.',{jaw:.08}),
  m:pose('M · B · P','m b p','map','Both lips meet. These sounds share a similar visible closure.',{jaw:.03,seal:1,width:.55}),
  f:pose('F · V','f v','five','The lower lip lifts toward the upper front teeth.',{jaw:.15,lower:1,upper:.45,width:.60}),
  th:pose('TH','θ ð','think','The tongue tip moves forward toward the front teeth.',{jaw:.26,width:.62,tongueForward:1,tongueUp:.25}),
  t:pose('T · D · N','t d n','ten','The tongue tip lifts toward the ridge behind the upper front teeth.',{jaw:.2,width:.61,tongueUp:.3,tongueCurl:.9,tongueForward:.60}),
  l:pose('L','l','lamp','The raised tongue tip is easiest to see in the cutaway view.',{jaw:.30,width:.60,tongueUp:.30,tongueCurl:1,tongueForward:.62}),
  k:pose('K · G · NG','k g ŋ','king','The back of the tongue rises; the tongue tip stays lower.',{jaw:.24,width:.60,tongueUp:.1,tongueBack:1,tongueForward:.1}),
  s:pose('S · Z','s z','sun','The teeth are close together, with the tongue close behind them.',{jaw:.02,width:.66,upper:.4,lower:-.3,tongueUp:.65,tongueForward:.5}),
  ch:pose('SH · CH · J','ʃ ʒ tʃ dʒ','shoe','The lips round and project; the tongue rises behind the teeth.',{jaw:.19,width:.40,pucker:.48,tongueUp:.65,tongueForward:.4}),
  r:pose('R','ɹ','red','One simplified American R pose: tongue tip raised and curled back. Other R shapes exist.',{jaw:.19,width:.43,pucker:.35,tongueUp:.45,tongueCurl:.9,tongueForward:.08}),
  w:pose('W','w','we','A narrow rounded opening with the back of the tongue raised.',{jaw:.09,width:.30,pucker:.9,tongueBack:.7,tongueForward:.1}),
  ee:pose('EE · IH','i ɪ','see','Spread lips with the front of the tongue high. Grouped vowels are approximations.',{jaw:.08,width:.82,upper:.2,tongueUp:.85,tongueForward:.6}),
  eh:pose('EH · AE','ɛ æ','cat','A wider, more open mouth; the tongue stays toward the front.',{jaw:.50,width:.76,tongueUp:.35,tongueForward:.65}),
  ah:pose('AH · UH','ɑ ʌ','hot','The jaw opens and the tongue lies low. The skull stays fixed.',{jaw:.8,width:.6,tongueUp:.1,tongueForward:.3}),
  oh:pose('OH','oʊ ɔ','go','The lips round. This is a held reference pose, not the full moving vowel.',{jaw:.46,width:.38,pucker:.65,tongueBack:.5,tongueForward:.2}),
  oo:pose('OO','u ʊ','blue','A small rounded opening and a raised back of the tongue.',{jaw:.19,width:.29,pucker:1,tongueBack:.85,tongueForward:.05})
};
export function constrain(state) {
  for(const [key,[min,max]] of Object.entries(LIMITS)) {
    if(!Number.isFinite(state[key])) throw new Error(`Invalid ${key}`);
    state[key]=Math.max(min,Math.min(max,state[key]));
  }
  return state;
}
