const current=document.body.dataset.version||'v14';
const wrapper=document.createElement('div');wrapper.className='version-bar';
const label=document.createElement('label');label.htmlFor='version-select';label.textContent='Version';
const select=document.createElement('select');select.id='version-select';
for(const [value,text] of [['v14','Version 14 — Luzia pronunciation'],['v13','Version 13 — dark inner mouth'],['v12','Version 12 — lower-lip skin control'],['v11','Version 11 — shared saved visemes'],['v10','Version 10 — independent lip thickness'],['v9','Version 9 — direct tongue controls'],['v8','Version 8 — scrolling controls & lip Z'],['v7','Version 7 — picture guides & saved poses'],['v6','Version 6 — mirrored tongue profiles'],['v5','Version 5 — advanced tongue controls'],['v4','Version 4 — mouth-only view'],['v3','Version 3 — sentence writer'],['v2','Version 2 — previous 3D simulator']]){const option=document.createElement('option');option.value=value;option.textContent=text;option.selected=current===value;select.append(option)}
const info=document.createElement('span');info.textContent=current==='v14'?'Earlier versions remain available here.':'Previous version preserved exactly.';
wrapper.append(label,select,info);document.body.prepend(wrapper);
select.addEventListener('change',()=>{location.href=select.value==='v14'?'/index.html':`/versions/${select.value}/index.html`});
