import { constrain } from './poses.js';
import { jawPoint, lipPoint } from './rig.js';
import { Vector3 } from 'three';
export function prepareDrag(state,part) {
  return constrain({...state});
}
function releaseSeal(state,part) {
  const s={...state};
  if(['upper','lower','left','right'].includes(part)&&s.seal>0){
    const top=lipPoint(Math.PI/2,s).y,bottom=lipPoint(3*Math.PI/2,s).y;
    s.seal=0;s.upper=(top-.08)/.20;s.lower=(bottom-jawPoint(new Vector3(0,-.14,1.04),s).y)/.37;
  }
  return constrain(s);
}
export function applyDrag(start,part,delta) {
  if(!delta||![delta.x,delta.y,delta.z].every(Number.isFinite))throw new Error('Invalid drag');
  const s=Math.abs(delta.y)>1e-6?releaseSeal(start,part):{...start};
  switch(part){
    case 'upper':s.upper+=delta.y/.20;s.lipDepth+=delta.z/.18;break;
    case 'lower':s.lower+=delta.y/.37;s.lipDepth+=delta.z/.18;break;
    case 'left':case 'right':s.width+=delta.x*(part==='left'?-1:1)/(1-.32*s.pucker);s.upper+=delta.y/.20;s.lower+=delta.y/.37;s.lipDepth+=delta.z/.18;break;
    case 'tongueTip':s.tongueUp+=delta.y/.33;s.tongueForward+=delta.z/.57;s.tongueSide+=delta.x/.28;break;
    case 'tongueBack':s.tongueBack+=delta.y/.32;s.tongueForward+=delta.z/.57;s.tongueSide+=delta.x/.28;break;
    case 'chin':s.jaw-=delta.y/.72;s.forward+=delta.z/.16;break;
    default:throw new Error('Unknown part');
  }
  return constrain(s);
}
