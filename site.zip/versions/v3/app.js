import * as T from 'three';
import { OrbitControls } from './vendor/OrbitControls.js';
import { createRig } from './rig.js';
import { POSES, LIMITS, constrain } from './poses.js';
import { prepareDrag, applyDrag } from './manipulate.js';
import { setupSentencePlayer } from './sentence-player.js';
let sentencePlayer=null;
function stopSentence(){if(sentencePlayer?.isPlaying())sentencePlayer.stop()}
const $=id=>document.getElementById(id);
const canvas=$('mouth'),stage=$('stage');
const renderer=new T.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'low-power'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.setClearColor('#151e2d');renderer.localClippingEnabled=true;
renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
const scene=new T.Scene(),camera=new T.PerspectiveCamera(34,1,.1,50);
camera.position.set(3.7,1.85,7.4);
const controls=new OrbitControls(camera,canvas);controls.target.set(0,.55,0);controls.minDistance=3.7;controls.maxDistance=13;controls.enablePan=false;controls.enableDamping=false;controls.minPolarAngle=.3;controls.maxPolarAngle=Math.PI-.3;controls.update();
scene.add(new T.HemisphereLight('#d9eaff','#46404c',2.6));
const key=new T.DirectionalLight('#fff0df',3.3);key.position.set(-3,5,5);scene.add(key);
const fill=new T.DirectionalLight('#9fc9ff',2);fill.position.set(4,2,-3);scene.add(fill);
const rig=createRig();scene.add(rig.root);
const stand=new T.Mesh(new T.CylinderGeometry(1.7,1.7,.08,64),new T.MeshStandardMaterial({color:'#26364c',roughness:.8}));stand.position.y=-1.88;scene.add(stand);
const ring=new T.Mesh(new T.TorusGeometry(1.69,.012,8,96),new T.MeshBasicMaterial({color:'#49617e'}));ring.rotation.x=Math.PI/2;ring.position.y=-1.83;scene.add(ring);
let state={...POSES.rest.values},active='rest',lastPreset='rest',mode='skin',selected='upper',drag=null,undo=null;
const labels={upper:'Upper lip',lower:'Lower lip',left:'Left mouth corner',right:'Right mouth corner',tongueTip:'Tongue tip',tongueBack:'Tongue back',chin:'Jaw / chin'};
const hints={upper:'Upper lip: drag vertically to lift or lower it. Drag in depth to move both lips forward or back.',lower:'Lower lip: drag vertically independently of the jaw. Depth movement preserves a closed mouth.',left:'Mouth corner: drag outward to widen or inward to narrow. Corners move symmetrically.',right:'Mouth corner: drag outward to widen or inward to narrow. Corners move symmetrically.',tongueTip:'Tongue tip: drag up, down, sideways or forward. Use Fine adjustments for tip curl.',tongueBack:'Tongue back: drag up or down to raise or lower the tongue body.',chin:'Jaw: drag down to open, up to close. The lower teeth follow while the skull stays still.'};
function render(){renderer.render(scene,camera)}
function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();render()}
new ResizeObserver(resize).observe(stage);controls.addEventListener('change',()=>{$('grabLabel').classList.add('hidden');render()});
const sliders=new Map();
function refresh(){
  rig.update(state);$('poseName').textContent=active==='custom'?`Custom · from ${POSES[lastPreset].name}`:POSES[active].name;
  $('poseNote').textContent=active==='custom'?'Your edited pose. Click any sound to replace it instantly, or Reset pose to return to the starting sound.':POSES[active].note;
  document.querySelectorAll('[data-pose]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.pose===active)));
  for(const [k,{input,output}] of sliders){input.value=state[k];output.value=k==='width'?Math.round(state[k]*100):Math.round(state[k]*100)}
  $('undo').disabled=!undo; $('hear').disabled=lastPreset==='rest'||!('speechSynthesis' in window);
  render();
}
function setPreset(key){stopSentence();if(!Object.hasOwn(POSES,key))throw new Error('Unknown viseme');endDrag();undo={state:{...state},active,lastPreset};state={...POSES[key].values};active=lastPreset=key;refresh();if($('autoSpeak').checked)hear()}
for(const [id,p] of Object.entries(POSES)){const b=document.createElement('button');b.className='sound';b.dataset.pose=id;b.setAttribute('aria-label',`${p.name}${p.word?', as in '+p.word:''}`);b.setAttribute('aria-pressed',String(id==='rest'));const strong=document.createElement('strong');strong.textContent=p.name;const small=document.createElement('small');small.textContent=p.word||'Neutral';b.append(strong,small);b.onclick=()=>setPreset(id);$('sounds').append(b)}
const definitions=[['jaw','Jaw opening'],['forward','Jaw forward'],['width','Mouth width'],['pucker','Pucker'],['lipDepth','Back ↔ forward'],['seal','Lip closure'],['upper','Upper lip lift'],['lower','Lower lip lift'],['tongueUp','Tongue height'],['tongueForward','Tongue forward'],['tongueBack','Tongue back lift'],['tongueCurl','Tongue-tip curl'],['tongueSide','Tongue sideways']];
for(const [key,title] of definitions){const row=document.createElement('div');row.className='slider-row';const l=document.createElement('label');l.htmlFor=`range-${key}`;l.textContent=title;const i=document.createElement('input');i.type='range';i.id=l.htmlFor;i.min=LIMITS[key][0];i.max=LIMITS[key][1];i.step=.01;i.value=state[key];const o=document.createElement('output');o.htmlFor=i.id;o.value=Math.round(state[key]*100);row.append(l,i,o);$(['pucker','lipDepth','seal'].includes(key)?'lipSliders':'sliders').append(row);sliders.set(key,{input:i,output:o});i.addEventListener('pointerdown',snapshot);i.addEventListener('keydown',e=>{if(e.key.startsWith('Arrow'))snapshot()});i.oninput=()=>{stopSentence();state[key]=Number(i.value);state=constrain(state);active='custom';refresh()}}
function snapshot(){stopSentence();undo={state:{...state},active,lastPreset};$('undo').disabled=false}
$('undo').onclick=()=>{stopSentence();if(!undo)return;endDrag();state=undo.state;active=undo.active;lastPreset=undo.lastPreset;undo=null;refresh()};
$('reset').onclick=()=>setPreset(lastPreset);
$('closeLips').onclick=()=>{snapshot();state.seal=1;active='custom';refresh()};
$('puckerLips').onclick=()=>{snapshot();state.pucker=1;active='custom';refresh()};
// Render the actual 3D visemes into popup thumbnails, using one off-screen target.
let thumbnailsReady=false;
function makeThumbnails(){
  const w=240,h=180,target=new T.WebGLRenderTarget(w,h),pixels=new Uint8Array(w*h*4);
  target.texture.colorSpace=T.SRGBColorSpace;
  const thumbCamera=new T.OrthographicCamera(-1.04,1.04,.78,-.78,.1,20);thumbCamera.position.set(0,-.12,5);thumbCamera.lookAt(0,-.12,0);
  const output=document.createElement('canvas');output.width=w;output.height=h;const ctx=output.getContext('2d'),data=ctx.createImageData(w,h);
  const oldTarget=renderer.getRenderTarget(),handlesVisible=rig.handles.visible;
  try{
    rig.setMode('skin');rig.handles.visible=false;
    for(const [id,p] of Object.entries(POSES)){
      rig.update(p.values);renderer.setRenderTarget(target);renderer.render(scene,thumbCamera);renderer.readRenderTargetPixels(target,0,0,w,h,pixels);
      for(let y=0;y<h;y++)data.data.set(pixels.subarray((h-y-1)*w*4,(h-y)*w*4),y*w*4);
      ctx.putImageData(data,0,0);const b=document.createElement('button');b.className='viseme-tile';b.dataset.pose=id;b.setAttribute('aria-pressed',String(active===id));
      const img=document.createElement('img');img.src=output.toDataURL('image/png');img.alt=`${p.name} mouth shape`;const strong=document.createElement('strong');strong.textContent=p.name;const text=document.createElement('span');text.textContent=p.word?`/${p.ipa}/ · “${p.word}”`:'Neutral resting shape';b.append(img,strong,text);b.onclick=()=>{$('visemeDialog').close();setPreset(id)};$('visemeGrid').append(b);
    }
    thumbnailsReady=true;
  }finally{renderer.setRenderTarget(oldTarget);target.dispose();rig.update(state);rig.setMode(mode);rig.handles.visible=handlesVisible;render()}
}
$('openVisemes').onclick=()=>{stopSentence();endDrag();if(!thumbnailsReady)makeThumbnails();$('visemeDialog').showModal()};
$('closeVisemes').onclick=()=>$('visemeDialog').close();
$('visemeDialog').addEventListener('click',e=>{if(e.target===$('visemeDialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close()}});
function setLayer(layer){if(!['skin','xray','skull','cutaway'].includes(layer))throw Error('Unknown layer');endDrag();mode=layer;rig.setMode(layer);document.querySelectorAll('[data-layer]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.layer===layer)));if(layer==='cutaway')setCamera('side');render()}
document.querySelectorAll('[data-layer]').forEach(b=>b.onclick=()=>setLayer(b.dataset.layer));
function setCamera(view){endDrag();const positions={front:[0,.85,8.2],three:[3.7,1.85,7.4],side:[8.2,.75,.01]};camera.position.set(...positions[view]);controls.target.set(0,.55,0);controls.update();render()}
document.querySelectorAll('[data-camera]').forEach(b=>b.onclick=()=>setCamera(b.dataset.camera));
function selectPart(part){selected=part;$('part').value=part;$('partHint').textContent=hints[part];if(part.startsWith('tongue')&&mode==='skin')setLayer('xray');for(const [key,h] of Object.entries(rig.handleMap))h.scale.setScalar(key===part?1.2:1);render()}
$('part').onchange=e=>selectPart(e.target.value);
$('showHandles').onchange=e=>{rig.handles.visible=e.target.checked;render()};
$('dragPlane').onchange=endDrag;
function hear(){stopSentence();const word=POSES[lastPreset].word;if(!word)return;if(!('speechSynthesis' in window)){$('audioStatus').textContent='Audio unavailable';return}window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(word);utterance.lang='en-US';utterance.rate=.72;utterance.onstart=()=>{$('audioStatus').textContent=`“${word}”`};utterance.onend=()=>{$('audioStatus').textContent=''};utterance.onerror=()=>{$('audioStatus').textContent='Audio unavailable'};window.speechSynthesis.speak(utterance)}
$('hear').onclick=hear;
const raycaster=new T.Raycaster(),pointer=new T.Vector2();
function ray(e){const r=canvas.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera)}
function visible(o){for(let n=o;n;n=n.parent)if(!n.visible)return false;return true}
function pick(e){ray(e);scene.updateMatrixWorld(true);const hs=rig.handles.visible?raycaster.intersectObjects(Object.values(rig.handleMap)).filter(h=>visible(h.object)):[];if(hs.length)return{part:hs[0].object.userData.part,point:hs[0].point};
  const hits=raycaster.intersectObject(rig.root,true);
  for(const h of hits){if(!visible(h.object)||h.object.parent===rig.handles)continue;if(mode==='cutaway'&&h.point.x>0.001)continue;
    if(h.object.userData.part)return{part:h.object.userData.part,point:h.point};
    if(h.object.parent===rig.jaw&&h.object.name!=='Floor of mouth')return{part:'chin',point:h.point};
    if(h.object.parent===rig.skin){if(mode==='xray')continue;if(h.point.y<-.40)return{part:'chin',point:h.point};return null}
    return null;
  }return null;
}
canvas.addEventListener('pointerdown',e=>{if(e.button!==0||drag)return;stopSentence();const hit=pick(e);if(!hit)return;
  snapshot();selectPart(hit.part);state=prepareDrag(state,hit.part);const plane=new T.Plane().setFromNormalAndCoplanarPoint(camera.getWorldDirection(new T.Vector3()),hit.point);ray(e);const origin=raycaster.ray.intersectPlane(plane,new T.Vector3());if(!origin)return;
  drag={id:e.pointerId,part:hit.part,start:{...state},plane,origin:origin.clone(),screen:{x:e.clientX,y:e.clientY},direction:$('dragPlane').value,scale:2*camera.position.distanceTo(hit.point)*Math.tan(T.MathUtils.degToRad(camera.fov/2))/stage.clientHeight};
  controls.enabled=false;canvas.setPointerCapture(e.pointerId);canvas.classList.add('dragging');e.preventDefault();e.stopImmediatePropagation();
},true);
canvas.addEventListener('pointermove',e=>{
  if(!drag){const h=pick(e);canvas.classList.toggle('over-part',!!h);const box=$('grabLabel');if(h){box.textContent=labels[h.part];const r=stage.getBoundingClientRect();box.style.left=`${Math.min(e.clientX-r.left,stage.clientWidth-170)}px`;box.style.top=`${e.clientY-r.top}px`;box.classList.remove('hidden')}else box.classList.add('hidden');return}
  if(e.pointerId!==drag.id)return;const delta=new T.Vector3();if(drag.direction==='view'){ray(e);const point=raycaster.ray.intersectPlane(drag.plane,new T.Vector3());if(!point)return;delta.copy(point).sub(drag.origin)}else{const amount=drag.direction==='x'?(e.clientX-drag.screen.x)*drag.scale:-(e.clientY-drag.screen.y)*drag.scale;delta[drag.direction]=amount}
  state=applyDrag(drag.start,drag.part,delta);active='custom';refresh();$('grabLabel').classList.add('hidden');e.preventDefault();e.stopImmediatePropagation();
},true);
function endDrag(){if(!drag)return;const id=drag.id;drag=null;if(canvas.hasPointerCapture(id))canvas.releasePointerCapture(id);controls.enabled=true;canvas.classList.remove('dragging')}
for(const event of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(event,endDrag,true);
canvas.addEventListener('pointerleave',()=>{if(!drag)$('grabLabel').classList.add('hidden')});
canvas.addEventListener('keydown',e=>{const delta=new T.Vector3(),step=e.shiftKey?.05:.02;switch(e.key){case'ArrowUp':delta.y=step;break;case'ArrowDown':delta.y=-step;break;case'ArrowLeft':delta.x=-step;break;case'ArrowRight':delta.x=step;break;case'PageUp':delta.z=step;break;case'PageDown':delta.z=-step;break;default:return}e.preventDefault();snapshot();state=applyDrag(prepareDrag(state,selected),selected,delta);active='custom';refresh()});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();$('error').classList.remove('hidden');$('error').textContent='The 3D graphics context was interrupted. Reload this page to restart the viewer.'});
// Use the same validated actions for the retained page-scoped viseme tool.
if(document.modelContext?.registerTool){const life=new AbortController();try{Promise.resolve(document.modelContext.registerTool({name:'set_viseme',title:'Set viseme',description:'Instantly set the editable 3D mouth to an English sound pose.',inputSchema:{type:'object',properties:{sound:{type:'string',enum:Object.keys(POSES)}},required:['sound'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute(input){if(!input||!Object.hasOwn(POSES,input.sound))throw Error('Unknown sound');setPreset(input.sound);return{selected:POSES[input.sound].name,values:{...state}}}},{signal:life.signal})).catch(()=>{});window.addEventListener('pagehide',()=>life.abort(),{once:true})}catch{}}
rig.setMode(mode);refresh();resize();
sentencePlayer=setupSentencePlayer({onStart(){endDrag()},showPose(id){rig.update(POSES[id].values);render()},onFinish(){rig.update(state);render()}});
