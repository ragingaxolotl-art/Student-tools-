import * as THREE from 'three';

const solidCanvas=document.getElementById('solidCanvas');
const projectionCanvas=document.getElementById('projectionCanvas');
const solidRenderer=new THREE.WebGLRenderer({canvas:solidCanvas,antialias:true});
const projectionRenderer=new THREE.WebGLRenderer({canvas:projectionCanvas,antialias:true,alpha:true});
solidRenderer.setPixelRatio(Math.min(devicePixelRatio,2));
projectionRenderer.setPixelRatio(Math.min(devicePixelRatio,2));
solidRenderer.outputColorSpace=projectionRenderer.outputColorSpace=THREE.SRGBColorSpace;
solidRenderer.shadowMap.enabled=true;
solidRenderer.shadowMap.type=THREE.PCFSoftShadowMap;

const solidScene=new THREE.Scene();solidScene.background=new THREE.Color(0x172135);
const projectionScene=new THREE.Scene();projectionScene.background=null;
const camera=new THREE.PerspectiveCamera(38,1,.1,100);camera.position.set(0,0,9);camera.lookAt(0,0,0);
const projectionCamera=new THREE.OrthographicCamera(-3.6,3.6,3.6,-3.6,.1,100);projectionCamera.position.set(0,0,10);projectionCamera.lookAt(0,0,0);

const ambient=new THREE.HemisphereLight(0xdbe8ff,0x172135,.72);solidScene.add(ambient);
const directional=new THREE.DirectionalLight(0xffffff,3.2);directional.position.set(-5,5,7);directional.castShadow=true;solidScene.add(directional);
const projectionAmbient=new THREE.AmbientLight(0xffffff,.65);projectionScene.add(projectionAmbient);
const projectionLight=new THREE.DirectionalLight(0xffffff,2.8);projectionLight.position.copy(directional.position);projectionScene.add(projectionLight);
const floor=new THREE.Mesh(new THREE.CircleGeometry(4.5,64),new THREE.ShadowMaterial({color:0x050811,opacity:.26}));floor.rotation.x=-Math.PI/2;floor.position.y=-2.05;floor.receiveShadow=true;solidScene.add(floor);

const palette=[0x416fe0,0xffb454,0x6fd5d0,0xef5c64,0x8d6ce8,0xf5d35f,0x38a97b,0xf58ba8];
const materialSet=()=>palette.map(color=>new THREE.MeshStandardMaterial({color,roughness:.62,metalness:.04,side:THREE.DoubleSide,flatShading:true}));
let solidGroup,projectionGroup,currentGeometry,currentShape='rect';
const rotation={x:0,y:0,z:0};
let targetRotation={...rotation},auto=false,autoAxis='y',dragging=false,lastPointer={x:0,y:0},cameraDistance=9;
const cameraDirection=new THREE.Vector3(0,0,1),cameraUp=new THREE.Vector3(0,1,0);

function makeGeometry(type){
  let geometry;
  if(type==='rect')geometry=new THREE.BoxGeometry(3.8,2.45,1.65);
  if(type==='cube')geometry=new THREE.BoxGeometry(2.8,2.8,2.8);
  if(type==='triPrism'){geometry=new THREE.CylinderGeometry(1.75,1.75,3.4,3,1,false);geometry.rotateZ(Math.PI/2)}
  if(type==='cylinder')geometry=new THREE.CylinderGeometry(1.55,1.55,3.15,48,1,false);
  if(type==='cone')geometry=new THREE.ConeGeometry(1.75,3.4,48);
  if(type==='pyramid')geometry=new THREE.ConeGeometry(1.85,3.4,4);geometry.rotateY(Math.PI/4);
  if(type==='sphere')geometry=new THREE.SphereGeometry(1.75,48,32);
  geometry.computeBoundingBox();geometry.computeVertexNormals();return geometry;
}
function meshGroup(geometry,projection=false){
  const group=new THREE.Group();
  const mats=materialSet();
  if(projection)mats.forEach(m=>{m.roughness=.9;m.metalness=0});
  const mesh=new THREE.Mesh(geometry,geometry.groups.length?mats:mats[0]);mesh.castShadow=!projection;mesh.receiveShadow=!projection;group.add(mesh);
  const edges=new THREE.LineSegments(new THREE.EdgesGeometry(geometry,18),new THREE.LineBasicMaterial({color:projection?0x243555:0x0b1020,transparent:true,opacity:projection?.92:.66}));
  group.add(edges);return group;
}
function setShape(type){
  if(solidGroup)solidScene.remove(solidGroup);if(projectionGroup)projectionScene.remove(projectionGroup);
  currentShape=type;currentGeometry=makeGeometry(type);solidGroup=meshGroup(currentGeometry,false);projectionGroup=meshGroup(currentGeometry,true);solidScene.add(solidGroup);projectionScene.add(projectionGroup);updateGroups();updateReadout();
}
function updateGroups(){for(const group of [solidGroup,projectionGroup])if(group)group.rotation.set(rotation.x,rotation.y,rotation.z)}
function degrees(radians){let value=Math.round(THREE.MathUtils.radToDeg(radians)%360);if(value<0)value+=360;return value}
function projectedBounds(){
  const box=currentGeometry.boundingBox;const points=[];
  for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(new THREE.Vector3(x,y,z));
  const matrix=new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(rotation.x,rotation.y,rotation.z));
  const coords=points.map(p=>p.applyMatrix4(matrix).project(projectionCamera));
  return {w:(Math.max(...coords.map(p=>p.x))-Math.min(...coords.map(p=>p.x)))*3.6,h:(Math.max(...coords.map(p=>p.y))-Math.min(...coords.map(p=>p.y)))*3.6};
}
function edgeOnLabel(){
  if(!['rect','cube'].includes(currentShape))return '';
  const euler=new THREE.Euler(rotation.x,rotation.y,rotation.z),view=new THREE.Vector3();projectionCamera.getWorldDirection(view);
  const normals=[['front face',new THREE.Vector3(0,0,1)],['side face',new THREE.Vector3(1,0,0)],['top face',new THREE.Vector3(0,1,0)]];
  const hit=normals.find(([,n])=>Math.abs(n.applyEuler(euler).dot(view))<.025);
  return hit?`The ${hit[0]} is edge-on, so its 2D projection has collapsed to a line.`:'';
}
function updateReadout(){
  if(!currentGeometry)return;
  document.getElementById('rotationReadout').textContent=`X ${degrees(rotation.x)}° · Y ${degrees(rotation.y)}° · Z ${degrees(rotation.z)}°`;
  const b=projectedBounds();document.getElementById('sizeReadout').textContent=`${b.w.toFixed(1)} × ${b.h.toFixed(1)} projected units`;
  const edge=edgeOnLabel();document.getElementById('observation').textContent=edge||'Several faces overlap in the flat view. Their depth is no longer recorded.';
}
function setProjection(value){
  const positions={front:[0,0,10],side:[10,0,0],top:[0,10,0.001]};
  const up=value==='top'?[0,0,-1]:[0,1,0];
  projectionCamera.position.set(...positions[value]);projectionCamera.up.set(...up);projectionCamera.lookAt(0,0,0);projectionCamera.updateMatrixWorld();
  cameraDirection.set(...positions[value]).normalize();cameraUp.set(...up);camera.up.copy(cameraUp);camera.position.copy(cameraDirection).multiplyScalar(cameraDistance);camera.lookAt(0,0,0);camera.updateMatrixWorld();
  updateReadout();
}
function setLight(value){
  const positions={frontLeft:[-5,5,7],frontRight:[5,5,7],above:[0,9,1],below:[0,-7,4],behind:[0,3,-8],flat:[0,4,7]};directional.position.set(...positions[value]);projectionLight.position.copy(directional.position);
  const flat=value==='flat';ambient.intensity=flat?1.5:.72;directional.intensity=(Number(document.getElementById('lightStrength').value)/100)*(flat?1.35:4);projectionAmbient.intensity=flat?1.25:.65;projectionLight.intensity=directional.intensity*.85;
}
const renderSize={sw:0,sh:0,pw:0,ph:0};
function resize(){
  const sr=solidCanvas.getBoundingClientRect(),pr=projectionCanvas.getBoundingClientRect();
  const sw=Math.max(1,Math.round(sr.width)),sh=Math.max(1,Math.round(sr.height)),pw=Math.max(1,Math.round(pr.width)),ph=Math.max(1,Math.round(pr.height));
  if(renderSize.sw!==sw||renderSize.sh!==sh){renderSize.sw=sw;renderSize.sh=sh;solidRenderer.setSize(sw,sh,false);camera.aspect=sw/sh;camera.updateProjectionMatrix()}
  if(renderSize.pw!==pw||renderSize.ph!==ph){renderSize.pw=pw;renderSize.ph=ph;projectionRenderer.setSize(pw,ph,false);const aspect=pw/ph;projectionCamera.left=-3.6*aspect;projectionCamera.right=3.6*aspect;projectionCamera.top=3.6;projectionCamera.bottom=-3.6;projectionCamera.updateProjectionMatrix()}
}
function animate(){
  requestAnimationFrame(animate);resize();
  if(auto){targetRotation[autoAxis]+=.008}
  let changed=false;for(const axis of ['x','y','z']){const delta=targetRotation[axis]-rotation[axis];if(Math.abs(delta)>.0002){rotation[axis]+=delta*(auto ? .28 : .14);changed=true}else rotation[axis]=targetRotation[axis]}
  if(changed){updateGroups();updateReadout()}
  camera.up.copy(cameraUp);camera.position.copy(cameraDirection).multiplyScalar(cameraDistance);camera.lookAt(0,0,0);
  solidRenderer.render(solidScene,camera);projectionRenderer.render(projectionScene,projectionCamera);
}

document.getElementById('shapeSelect').addEventListener('change',e=>setShape(e.target.value));
document.getElementById('projectionSelect').addEventListener('change',e=>setProjection(e.target.value));
document.getElementById('lightSelect').addEventListener('change',e=>setLight(e.target.value));
document.getElementById('lightStrength').addEventListener('input',e=>{document.getElementById('lightOutput').textContent=`${e.target.value}%`;setLight(document.getElementById('lightSelect').value)});
document.querySelectorAll('[data-axis]').forEach(button=>button.addEventListener('click',()=>{const step=THREE.MathUtils.degToRad(Number(document.getElementById('stepSelect').value));targetRotation[button.dataset.axis]+=step*Number(button.dataset.direction)}));
document.getElementById('stepSelect').addEventListener('change',e=>document.querySelectorAll('[data-axis]').forEach(button=>button.setAttribute('aria-label',`Rotate ${button.dataset.direction==='1'?'positive':'negative'} ${e.target.value} degrees on the ${button.dataset.axis.toUpperCase()} axis`)));
document.getElementById('resetRotation').addEventListener('click',()=>{targetRotation={x:0,y:0,z:0};auto=false;syncAutoButton()});
document.getElementById('edgeOn').addEventListener('click',()=>{targetRotation={x:0,y:Math.PI/2,z:0};auto=false;syncAutoButton()});
document.getElementById('autoAxis').addEventListener('change',e=>autoAxis=e.target.value);
document.getElementById('toggleAuto').addEventListener('click',()=>{auto=!auto;syncAutoButton()});
function syncAutoButton(){const button=document.getElementById('toggleAuto');button.setAttribute('aria-pressed',String(auto));button.textContent=auto?'❚❚ Pause':'▶ Play'}

solidCanvas.addEventListener('pointerdown',e=>{dragging=true;lastPointer={x:e.clientX,y:e.clientY};solidCanvas.setPointerCapture(e.pointerId);solidCanvas.classList.add('dragging')});
solidCanvas.addEventListener('pointermove',e=>{if(!dragging)return;const dx=e.clientX-lastPointer.x,dy=e.clientY-lastPointer.y;targetRotation.y+=dx*.012;targetRotation.x+=dy*.012;lastPointer={x:e.clientX,y:e.clientY}});
const endDrag=e=>{dragging=false;solidCanvas.classList.remove('dragging');if(e.pointerId!==undefined&&solidCanvas.hasPointerCapture(e.pointerId))solidCanvas.releasePointerCapture(e.pointerId)};
solidCanvas.addEventListener('pointerup',endDrag);solidCanvas.addEventListener('pointercancel',endDrag);
solidCanvas.addEventListener('wheel',e=>{e.preventDefault();cameraDistance=THREE.MathUtils.clamp(cameraDistance+Math.sign(e.deltaY)*.55,6,14)},{passive:false});

setShape('rect');setProjection('front');setLight('frontLeft');animate();
