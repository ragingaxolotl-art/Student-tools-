import { POSES } from './poses.js';
const phoneMap={AA:['ah'],AE:['eh'],AH:['ah'],AO:['oh'],AW:['ah','oo'],AY:['ah','ee'],B:['m'],CH:['ch'],D:['t'],DH:['th'],EH:['eh'],ER:['r'],EY:['eh','ee'],F:['f'],G:['k'],HH:['ah'],IH:['ee'],IY:['ee'],JH:['ch'],K:['k'],L:['l'],M:['m'],N:['t'],NG:['k'],OW:['oh','oo'],OY:['oh','ee'],P:['m'],R:['r'],S:['s'],SH:['ch'],T:['t'],TH:['th'],UH:['oo'],UW:['oo'],V:['f'],W:['w'],Y:['ee'],Z:['s'],ZH:['ch']};
// Browser speech voices and CMUdict do not always know the same proper names.
// Keep confirmed pronunciations here so voice playback and viseme animation agree.
export const supplementalPronunciations={luzia:'L UW1 Z IY0 AH0'};
export function analyzeSentence(text,dictionary,rate=.8){
  if(typeof text!=='string'||!text.trim())throw Error('Write a sentence first.');
  if(text.length>300)throw Error('Please keep the sentence under 300 characters.');
  if(!Number.isFinite(rate)||rate<.4||rate>1.5)throw Error('Invalid speech speed.');
  const words=[],frames=[],unknown=[];let time=0;
  for(const match of text.matchAll(/[\p{L}\p{N}]+(?:['’][\p{L}]+)*/gu)){
    const word=match[0],key=word.toLowerCase().replaceAll('’',"'"),pron=Object.hasOwn(dictionary,key)?dictionary[key]:supplementalPronunciations[key]||null;
    const phones=pron?pron.split(/\s+/):[];const steps=[];
    for(let i=0;i<phones.length;i++){
      const phone=phones[i].replace(/[012]/g,'');let shapes=phoneMap[phone];
      // H anticipates the following mouth shape instead of inventing a unique H viseme.
      if(phone==='HH')shapes=phoneMap[phones[i+1]?.replace(/[012]/g,'')]||['ah'];
      if(!shapes)throw Error(`Unsupported phoneme: ${phone}`);
      const vowel=/^[AEIOU]/.test(phone);const duration=(vowel?.15:.09)/rate;
      for(const shape of shapes)steps.push({phone,shape,duration:duration/shapes.length});
    }
    if(!pron){unknown.push(word);steps.push({phone:'?',shape:'rest',duration:.4/rate})}
    const entry={word,index:words.length,charIndex:match.index,endChar:match.index+word.length,pronunciation:pron,steps,start:time};words.push(entry);
    for(const step of steps){frames.push({...step,start:time,end:time+step.duration,wordIndex:entry.index});time+=step.duration}
    const next=text.slice(entry.endChar);const pause=/^\s*[.!?;:]/.test(next)?.22:/^\s*,/.test(next)?.10:.035;
    entry.end=time;time+=pause/rate;
  }
  if(!words.length)throw Error('Please enter words, not just punctuation.');
  return {text,rate,words,frames,duration:time,unknown:[...new Set(unknown)]};
}
export function frameAt(plan,elapsed){return plan.frames.find(f=>elapsed>=f.start&&elapsed<f.end)||null}
export function guideText(plan){
  const used=[...new Set(plan.frames.map(f=>f.shape))];
  const lines=['VISEME MOUTH LAB — SENTENCE GUIDE','',`Sentence: ${plan.text}`,'','English pronunciation reference: CMU Pronouncing Dictionary plus confirmed supplemental names.','Timing is approximate; grouped visemes are simplified animation poses.','A word with several pronunciations uses the dictionary’s default entry.','Different sounds can share the same visible mouth shape.','','WORD-BY-WORD MOUTH SHAPES',''];
  for(const w of plan.words){lines.push(`${w.index+1}. ${w.word}`);if(!w.pronunciation){lines.push('   Pronunciation not found. The head stays neutral for this word.','   Check the spelling; spell numbers out as words.','');continue}lines.push(`   Pronunciation (ARPABET): ${w.pronunciation}`);for(const step of w.steps)lines.push(`   ${step.phone} -> ${POSES[step.shape].name}`);lines.push('')}
  lines.push('MOUTH SHAPES USED','');for(const shape of used)lines.push(`${POSES[shape].name}: ${POSES[shape].note}`,'');
  if(plan.unknown.length)lines.push(`Needs review: ${plan.unknown.join(', ')}`,'');
  lines.push('Diphthongs such as AY and OW move through two mouth shapes.','H uses the following sound’s mouth shape. Stress digits: 0 = unstressed; 1 = primary; 2 = secondary.','','Source: https://github.com/cmusphinx/cmudict','');return lines.join('\r\n');
}
