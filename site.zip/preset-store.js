import { POSES,constrain } from './poses.js';
const LOCAL_KEY='digitalMediaVisemePresetsV16';
const PIN_HASH='97f2f9fe286a15e921dcd596f1e5dbdbbaf83fb31e7e4d7708e114454153985e';
const API_ROOT=new URL('./api/presets',import.meta.url).href.replace(/\/$/,'');
function normalize(id,value){
  if(!Object.hasOwn(POSES,id)||!value||typeof value!=='object')return null;
  const next={...POSES[id].values};
  for(const key of Object.keys(next))if(Number.isFinite(value[key]))next[key]=value[key];
  try{return constrain(next)}catch{return null}
}
async function requestJson(fetchImpl,path,options={}){
  const response=await fetchImpl(`${API_ROOT}${path}`,{...options,headers:{'content-type':'application/json','x-viseme-version':'v16',...(options.headers||{})}});
  let body={};try{body=await response.json()}catch{}
  if(!response.ok){const error=new Error(body.error||'The shared viseme service is unavailable.');error.status=response.status;throw error}
  return body;
}
function readLocal(){
  try{const parsed=JSON.parse(localStorage.getItem(LOCAL_KEY)||'{}'),clean={};for(const [id,value] of Object.entries(parsed)){const valid=normalize(id,value);if(valid)clean[id]=valid}return clean}catch{return{}}
}
function writeLocal(custom){try{localStorage.setItem(LOCAL_KEY,JSON.stringify(custom))}catch{}}
async function pinMatches(pin){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(pin??'')));return[...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('')===PIN_HASH}
export async function createPresetStore(fetchImpl=globalThis.fetch){
  let custom={};
  let mode='shared';
  try{const loaded=await requestJson(fetchImpl,'');for(const [id,value] of Object.entries(loaded.presets||{})){const valid=normalize(id,value);if(valid)custom[id]=valid}}catch{mode='browser';custom=readLocal()}
  async function change(path,options,localChange){
    if(mode==='shared'){try{await requestJson(fetchImpl,path,options);return}catch(error){if(error.status===403)throw error;mode='browser'}}
    localChange();writeLocal(custom);
  }
  return{
    get(id){if(!Object.hasOwn(POSES,id))throw Error('Unknown viseme');return{...(custom[id]||POSES[id].values)}},
    has(id){return Object.hasOwn(custom,id)},
    async save(id,value,pin){const valid=normalize(id,value);if(!valid)throw Error('The adjusted viseme is invalid.');await change(`/${encodeURIComponent(id)}`,{method:'PUT',body:JSON.stringify({pin,values:valid})},()=>{custom[id]=valid});custom[id]=valid;if(mode==='browser')writeLocal(custom);return{...valid}},
    async reset(id,pin){if(!Object.hasOwn(POSES,id))throw Error('Unknown viseme');await change(`/${encodeURIComponent(id)}`,{method:'DELETE',body:JSON.stringify({pin})},()=>{delete custom[id]});delete custom[id];if(mode==='browser')writeLocal(custom);return this.get(id)},
    async resetAll(pin){await change('',{method:'DELETE',body:JSON.stringify({pin})},()=>{custom={}});custom={};if(mode==='browser')writeLocal(custom)},
    ids(){return Object.keys(custom)},
    get available(){return true},
    get mode(){return mode}
  };
}
export async function verifyEditorPin(pin,fetchImpl=globalThis.fetch){
  try{await requestJson(fetchImpl,'/unlock',{method:'POST',body:JSON.stringify({pin})});return true}catch(error){if(error.status===403)return false;return pinMatches(pin)}
}
